Two Parallel Test Systems – V4 FAST (12 files per year)
Structure: RootFolder/<system>/<year>/<12 files>.xlsx

Key properties:
- 12 files per year for each system (monthly-style)
- YEARLY drift: year_added_<YYYY> exists in all files of that year
- MONTHLY drift: new_col_<YYYYMM> exists in each file (unique per month)
- Headers do NOT always start at row0/col0 (random header row + random start col A..F)
- Same meaning headers renamed wildly (synonyms/typos/symbols/spacing)
- Duplicate/conflicting columns + blank/Unnamed columns
- Repeated header mid-file (pagination)
- Multiple sheets per workbook + noise sheets

Truth sources:
- schema_drift_test_pack/file_inventory.csv
- schema_drift_test_pack/config/sheet_mapping_by_file.csv
